﻿namespace Abrigo_Final_BD
{
    partial class Servicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }




        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Servicos));
            Label2 = new Label();
            Label1 = new Label();
            adicionar_tratamento = new Button();
            adicionar_desparatisacao = new Button();
            adicionar_vacina = new Button();
            adicionar_doacao = new Button();
            label3 = new Label();
            label4 = new Label();
            adicionar_adocao = new Button();
            label5 = new Label();
            consultar_animal = new Button();
            voltar_atras = new Button();
            consultar_pessoas = new Button();
            adicionar_historial = new Button();
            SuspendLayout();
            // 
            // Label2
            // 
            Label2.Location = new Point(0, 0);
            Label2.Name = "Label2";
            Label2.Size = new Size(88, 22);
            Label2.TabIndex = 162;
            // 
            // Label1
            // 
            Label1.Location = new Point(0, 0);
            Label1.Name = "Label1";
            Label1.Size = new Size(88, 22);
            Label1.TabIndex = 163;
            // 
            // adicionar_tratamento
            // 
            adicionar_tratamento.Location = new Point(96, 104);
            adicionar_tratamento.Name = "adicionar_tratamento";
            adicionar_tratamento.Size = new Size(147, 68);
            adicionar_tratamento.TabIndex = 165;
            adicionar_tratamento.Text = "Adicionar Tratamento";
            adicionar_tratamento.UseVisualStyleBackColor = true;
            adicionar_tratamento.Click += adicionar_tratamento_Click;
            // 
            // adicionar_desparatisacao
            // 
            adicionar_desparatisacao.Location = new Point(726, 104);
            adicionar_desparatisacao.Name = "adicionar_desparatisacao";
            adicionar_desparatisacao.Size = new Size(148, 68);
            adicionar_desparatisacao.TabIndex = 166;
            adicionar_desparatisacao.Text = "Adicionar  Desparasitação";
            adicionar_desparatisacao.UseVisualStyleBackColor = true;
            adicionar_desparatisacao.Click += adicionar_desparatisacao_Click;
            // 
            // adicionar_vacina
            // 
            adicionar_vacina.Location = new Point(304, 104);
            adicionar_vacina.Name = "adicionar_vacina";
            adicionar_vacina.Size = new Size(147, 68);
            adicionar_vacina.TabIndex = 167;
            adicionar_vacina.Text = "Adicionar Vacina";
            adicionar_vacina.UseVisualStyleBackColor = true;
            adicionar_vacina.Click += adicionar_vacina_Click;
            // 
            // adicionar_doacao
            // 
            adicionar_doacao.Location = new Point(303, 275);
            adicionar_doacao.Name = "adicionar_doacao";
            adicionar_doacao.Size = new Size(148, 68);
            adicionar_doacao.TabIndex = 169;
            adicionar_doacao.Text = "Adicionar Doação";
            adicionar_doacao.UseVisualStyleBackColor = true;
            adicionar_doacao.Click += adicionar_doacao_Click;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label3.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point, 161);
            label3.Location = new Point(96, 55);
            label3.Margin = new Padding(4, 1, 4, 4);
            label3.Name = "label3";
            label3.Size = new Size(778, 19);
            label3.TabIndex = 171;
            label3.Text = "Serviços Disponíveis para Animais";
            label3.TextAlign = ContentAlignment.TopCenter;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label4.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point, 161);
            label4.Location = new Point(96, 232);
            label4.Margin = new Padding(4, 1, 4, 4);
            label4.Name = "label4";
            label4.Size = new Size(778, 19);
            label4.TabIndex = 172;
            label4.Text = "Outros Serviços";
            label4.TextAlign = ContentAlignment.TopCenter;
            // 
            // adicionar_adocao
            // 
            adicionar_adocao.Location = new Point(517, 275);
            adicionar_adocao.Name = "adicionar_adocao";
            adicionar_adocao.Size = new Size(148, 68);
            adicionar_adocao.TabIndex = 173;
            adicionar_adocao.Text = "Adicionar Adoção";
            adicionar_adocao.UseVisualStyleBackColor = true;
            adicionar_adocao.Click += adicionar_adocao_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label5.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point, 161);
            label5.Location = new Point(96, 403);
            label5.Margin = new Padding(4, 1, 4, 4);
            label5.Name = "label5";
            label5.Size = new Size(778, 19);
            label5.TabIndex = 174;
            label5.Text = "Consultar Animais/Membros";
            label5.TextAlign = ContentAlignment.TopCenter;
            // 
            // consultar_animal
            // 
            consultar_animal.Location = new Point(303, 443);
            consultar_animal.Name = "consultar_animal";
            consultar_animal.Size = new Size(148, 68);
            consultar_animal.TabIndex = 175;
            consultar_animal.Text = "Consultar Animais";
            consultar_animal.UseVisualStyleBackColor = true;
            consultar_animal.Click += consultar_animal_Click;
            // 
            // voltar_atras
            // 
            voltar_atras.Location = new Point(12, 12);
            voltar_atras.Name = "voltar_atras";
            voltar_atras.Size = new Size(114, 24);
            voltar_atras.TabIndex = 193;
            voltar_atras.Text = "<-";
            voltar_atras.UseVisualStyleBackColor = true;
            voltar_atras.Click += voltar_atras_Click;
            // 
            // consultar_pessoas
            // 
            consultar_pessoas.Location = new Point(517, 443);
            consultar_pessoas.Name = "consultar_pessoas";
            consultar_pessoas.Size = new Size(148, 68);
            consultar_pessoas.TabIndex = 194;
            consultar_pessoas.Text = "Consultar Pessoas";
            consultar_pessoas.UseVisualStyleBackColor = true;
            consultar_pessoas.Click += consultar_pessoas_Click;
            // 
            // adicionar_historial
            // 
            adicionar_historial.Location = new Point(517, 104);
            adicionar_historial.Name = "adicionar_historial";
            adicionar_historial.Size = new Size(148, 68);
            adicionar_historial.TabIndex = 195;
            adicionar_historial.Text = "Adicionar Historial";
            adicionar_historial.UseVisualStyleBackColor = true;
            adicionar_historial.Click += adicionar_historial_Click_1;
            // 
            // Servicos
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(947, 557);
            Controls.Add(adicionar_historial);
            Controls.Add(consultar_pessoas);
            Controls.Add(voltar_atras);
            Controls.Add(consultar_animal);
            Controls.Add(label5);
            Controls.Add(adicionar_adocao);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(adicionar_doacao);
            Controls.Add(adicionar_vacina);
            Controls.Add(adicionar_desparatisacao);
            Controls.Add(adicionar_tratamento);
            Controls.Add(Label2);
            Controls.Add(Label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "Servicos";
            Text = "Serviços de Abrigo de Carinho";
            ResumeLayout(false);
        }

        #endregion
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Button adicionar_tratamento;
        private System.Windows.Forms.Button adicionar_desparatisacao;
        private System.Windows.Forms.Button adicionar_vacina;
        private System.Windows.Forms.Button adicionar_doacao;
        internal Label label3;
        internal Label label4;
        private Button adicionar_adocao;
        internal Label label5;
        private Button consultar_animal;
        private Button voltar_atras;
        private Button consultar_pessoas;
        private Button adicionar_historial;
    }
}