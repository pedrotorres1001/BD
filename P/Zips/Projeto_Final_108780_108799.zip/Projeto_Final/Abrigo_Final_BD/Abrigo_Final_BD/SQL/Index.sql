--    Clustered indexes
CREATE CLUSTERED INDEX CL_IDX_Projeto_Funcionario ON Projeto_Funcionario (Num_func);

CREATE CLUSTERED INDEX CL_IDX_Projeto_Tratador ON Projeto_Tratador (Num_tratador);

CREATE CLUSTERED INDEX CL_IDX_Projeto_Animal ON Projeto_Animal (Num_chegada);


CREATE CLUSTERED INDEX CL_IDX_Projeto_Adotante ON Projeto_Adotante (Num_Adotante);


CREATE CLUSTERED INDEX CL_IDX_Projeto_Doador ON Projeto_Doador (Num_Doador);





----------------------------------------------------------------------



-- Unique indexes


